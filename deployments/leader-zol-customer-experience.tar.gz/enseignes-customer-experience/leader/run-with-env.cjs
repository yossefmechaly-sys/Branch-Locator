// Configuration stays on the VPS. Never print dotenv files or credential URLs.
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const {spawnSync} = require('node:child_process');
const target = require('./target.json');
const moduleRoot = process.env.RELEASE_MODULE_ROOT || process.cwd();
const resolve = name => require.resolve(name, {paths: [moduleRoot]});
const {loadEnvConfig} = require(resolve('@next/env'));
loadEnvConfig(process.cwd(), false, {info() {}, error() {
  console.error('Impossible de charger la configuration de production.');
  process.exit(1);
}});

async function databaseInfo() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL manquant.');
  const {Client} = require(resolve('pg'));
  const client = new Client({connectionString: process.env.DATABASE_URL, connectionTimeoutMillis: 10000});
  try {
    await client.connect();
    const {rows: [row]} = await client.query(`SELECT current_database() AS database,
      current_user AS username, inet_server_addr()::text AS address,
      inet_server_port() AS port, current_setting('server_version_num')::int AS version`);
    const url = new URL(process.env.DATABASE_URL);
    const address = !row.address || row.address === '::1' || row.address.startsWith('127.') ? 'local' : row.address;
    const identity = crypto.createHash('sha256').update(JSON.stringify([address, row.port || 5432, row.database])).digest('hex');
    const exists = await client.query("SELECT to_regclass('public._prisma_migrations') IS NOT NULL AS present");
    const migrations = exists.rows[0].present
      ? (await client.query('SELECT migration_name, finished_at IS NOT NULL AS finished, rolled_back_at IS NOT NULL AS rolled_back FROM public._prisma_migrations')).rows : [];
    return {identity, serverMajor: Math.floor(row.version / 10000), username: row.username,
      database: row.database, port: row.port || Number(url.port || 5432), migrations};
  } catch {
    throw new Error('Impossible de contrôler la base PostgreSQL ; aucune valeur de connexion affichée.');
  } finally { await client.end().catch(() => {}); }
}

function validate() {
  const missing = ['DATABASE_URL', 'AUTH_SECRET', 'NEXT_PUBLIC_SITE_URL'].filter(key => !process.env[key]);
  if (process.env.BRANCH_DEPLOY_REQUIRE_MAPS === '1' && !process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY) missing.push('NEXT_PUBLIC_GOOGLE_MAPS_API_KEY');
  if (missing.length) throw new Error('Configuration manquante : ' + missing.join(', '));
  for (const key of ['NEXT_PUBLIC_SITE_URL', 'AUTH_URL', 'NEXTAUTH_URL']) {
    if (process.env[key] && new URL(process.env[key]).origin !== target.site) {
      throw new Error(key + ' ne correspond pas au site à déployer.');
    }
  }
  console.log('Configuration de production vérifiée ; valeurs non affichées.');
}

async function backup(filename) {
  const info = await databaseInfo();
  const pgDir = '/usr/lib/postgresql/' + info.serverMajor + '/bin';
  const dump = fs.existsSync(pgDir + '/pg_dump') ? pgDir + '/pg_dump' : 'pg_dump';
  const restore = fs.existsSync(pgDir + '/pg_restore') ? pgDir + '/pg_restore' : 'pg_restore';
  const url = new URL(process.env.DATABASE_URL);
  if (!['postgres:', 'postgresql:'].includes(url.protocol)) throw new Error('Type de base inattendu.');
  const env = {...process.env,
    PGHOST: url.searchParams.get('host') || url.hostname.replace(/^\[|\]$/g, '') || process.env.PGHOST || 'localhost',
    PGPORT: url.port || String(info.port), PGDATABASE: decodeURIComponent(url.pathname.slice(1)) || info.database,
    PGUSER: decodeURIComponent(url.username) || process.env.PGUSER || info.username,
    PGPASSWORD: url.password ? decodeURIComponent(url.password) : (process.env.PGPASSWORD || ''),
  };
  for (const [query, key] of [['sslmode','PGSSLMODE'],['sslrootcert','PGSSLROOTCERT'],['sslcert','PGSSLCERT'],['sslkey','PGSSLKEY'],['options','PGOPTIONS']]) {
    if (url.searchParams.has(query)) env[key] = url.searchParams.get(query);
  }
  const result = spawnSync(dump, ['--format=custom', '--no-password', '--file=' + filename], {env, encoding: 'utf8'});
  if (result.status !== 0 || result.error) {
    fs.writeFileSync(filename + '.log', result.stderr || 'pg_dump indisponible', {mode: 0o600});
    throw new Error('Sauvegarde PostgreSQL impossible ; détails dans le journal privé de la sauvegarde.');
  }
  fs.chmodSync(filename, 0o600);
  const file = fs.openSync(filename, 'r');
  const header = Buffer.alloc(5);
  try { fs.readSync(file, header, 0, 5, 0); } finally { fs.closeSync(file); }
  if (header.toString() !== 'PGDMP') throw new Error('Format de sauvegarde PostgreSQL invalide.');
  const catalog = spawnSync(restore, ['--list', filename], {env, stdio: 'ignore'});
  if (catalog.status !== 0 || catalog.error) throw new Error('Le catalogue de sauvegarde PostgreSQL ne se relit pas.');
  console.log('Sauvegarde PostgreSQL créée et catalogue vérifié.');
}

async function main() {
  const mode = process.argv[2];
  if (mode === '--validate') validate();
  else if (mode === '--database-info') console.log(JSON.stringify(await databaseInfo()));
  else if (mode === '--backup') await backup(path.resolve(process.argv[3]));
  else if (mode === '--serve') require(path.resolve(process.argv[3]));
  else {
    const [command, ...args] = process.argv.slice(2);
    const result = spawnSync(command, args, {stdio: 'inherit', env: process.env});
    if (result.error) console.error('Impossible de lancer la commande de préparation.');
    process.exit(result.status ?? 1);
  }
}
main().catch(error => {
  console.error(['--validate','--backup'].includes(process.argv[2]) ? error.message : 'Contrôle de préparation impossible ; aucune valeur privée affichée.');
  process.exit(1);
});
