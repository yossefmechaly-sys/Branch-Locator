#!/usr/bin/env python3
"""Targeted deployment; run as franck, not with sudo. Secrets stay on the VPS."""
import datetime
import fcntl
import hashlib
import html
import json
import os
import re
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.parse
import urllib.request

PROJECT = Path('/home/franck/branch-locator')
PACKAGE = Path(__file__).resolve().parent
SERVICE = 'branch-locator.service'
BACKUP_SERVICE = 'branch-locator-backup.service'
SITE = 'https://branch-locator.tobedev.com'
NODE = '/usr/bin/node'
ENV_FILES = ('.env.production.local', '.env.local', '.env.production', '.env')
APP_KEYS = {
    'DATABASE_URL', 'AUTH_SECRET', 'AUTH_URL', 'AUTH_TRUST_HOST', 'NEXTAUTH_URL',
    'NEXTAUTH_SECRET', 'GOOGLE_GEOCODING_API_KEY', 'PORT', 'HOSTNAME',
    'BRANCH_UPLOAD_DIR', 'PROMOTION_UPLOAD_DIR', 'KEEP_ALIVE_TIMEOUT',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def checked(cmd, **kwargs):
    return subprocess.run(cmd, check=True, **kwargs)


def unit_properties(unit, names):
    command = ['systemctl', 'show', '--no-pager', '--full', '--all', unit]
    command.extend('--property=' + name for name in names)
    result = subprocess.check_output(command, text=True)
    return dict(line.split('=', 1) for line in result.splitlines() if '=' in line)


def verify_payload(package, manifest):
    for name, hashes in manifest.items():
        path = package / 'source' / name
        if not path.resolve().is_relative_to((package / 'source').resolve()):
            raise RuntimeError('Chemin de paquet invalide.')
        if digest(path) != hashes['after_sha256']:
            raise RuntimeError('Paquet incomplet ou altéré : ' + name)


def verify_base(project, manifest):
    original = updated = 0
    conflicts = []
    for name, hashes in manifest.items():
        path = project / name
        if path.is_symlink():
            raise RuntimeError('Un fichier à modifier est un lien symbolique : ' + name)
        if not path.resolve().is_relative_to(project.resolve()):
            raise RuntimeError('Un fichier à modifier pointe hors du projet : ' + name)
        value = digest(path)
        original += value == hashes['before_sha256']
        updated += value == hashes['after_sha256']
        if value not in (hashes['before_sha256'], hashes['after_sha256']):
            conflicts.append(name)
    if conflicts:
        raise RuntimeError('Fichiers du VPS différents de l’archive : ' + ', '.join(conflicts))
    if original != len(manifest) and updated != len(manifest):
        raise RuntimeError('Mise à jour partielle détectée ; inspection nécessaire.')


def replace_entry(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_symlink():
        target.unlink()
    shutil.copy2(source, target)


class FileSwitch:
    """Record enough state to recover from failure at any promotion step."""
    def __init__(self, project, stage, package, manifest, backup):
        self.project, self.stage, self.package = project, stage, package
        self.manifest, self.backup = manifest, backup
        self.artifacts_moved = []
        self.code_touched = False
        self.existing = set()
        backup.mkdir(parents=True)
        for name in manifest:
            path = project / name
            if path.exists():
                self.existing.add(name)
                target = backup / 'source' / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)

    def promote(self):
        self.code_touched = True
        for name in self.manifest:
            replace_entry(self.package / 'source' / name, self.project / name)
        for name in ('.next', 'node_modules'):
            current = self.project / name
            if current.exists() or current.is_symlink():
                current.rename(self.backup / name)
            self.artifacts_moved.append(name)
            (self.stage / name).rename(current)

    def rollback(self):
        for name in reversed(self.artifacts_moved):
            current = self.project / name
            if current.exists() or current.is_symlink():
                current.rename(self.backup / ('failed-' + name.lstrip('.')))
            old = self.backup / name
            if old.exists() or old.is_symlink():
                old.rename(current)
        if self.code_touched:
            for name in self.manifest:
                if name in self.existing:
                    replace_entry(self.backup / 'source' / name, self.project / name)
                else:
                    (self.project / name).unlink(missing_ok=True)


def request(base, path):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(base + path, timeout=10) as response:
        return response.read()


def wait_health(base, process=None):
    for _ in range(40):
        if process and process.poll() is not None:
            raise RuntimeError('Le serveur de vérification s’est arrêté ; consulter candidate.log.')
        try:
            if json.loads(request(base, '/api/health'))['status'] == 'ok':
                return
        except Exception:
            pass
        time.sleep(1)
    raise RuntimeError('Le contrôle de santé ne répond pas correctement.')


def check_feature(base):
    branches = json.loads(request(base, '/api/branches?locale=fr'))['branches']
    for branch in branches:
        rating = branch.get('reviewRating')
        if not isinstance(rating, dict) or type(rating.get('total')) is not int or rating['total'] < 0:
            raise RuntimeError('La liste ne renvoie pas les statistiques des avis.')
        average = rating.get('averageRating')
        if (rating['total'] == 0 and average is not None) or (rating['total'] > 0 and
                (type(average) not in (int, float) or not 1 <= average <= 5)):
            raise RuntimeError('Moyenne des avis incohérente dans la liste.')
    if branches:
        listing = request(base, '/he/branches').decode()
        first_href = '/he/branches/' + urllib.parse.quote(branches[0]['slug'], safe='') + '#reviews'
        if 'href="' + first_href + '"' not in listing:
            raise RuntimeError('Le lien vers les avis manque sur la carte magasin.')
    login = request(base, '/admin/login').decode()
    if 'type="password"' not in login:
        raise RuntimeError('Le formulaire de connexion admin ne se charge pas.')
    if branches:
        slug = urllib.parse.quote(branches[0]['slug'], safe='')
        reviews = json.loads(request(base, '/api/branches/' + slug + '/reviews'))
        if not isinstance(reviews.get('reviews'), list) or 'summary' not in reviews:
            raise RuntimeError('La nouvelle API d’avis ne répond pas correctement.')
        page = request(base, '/fr/branches/' + slug).decode()
        if 'Avis et satisfaction client' not in page:
            raise RuntimeError('La section d’avis manque sur la fiche magasin.')
        assets = {html.unescape(path) for path in re.findall(r'(?:src|href)="([^" ]+)"', page)
                  if path.startswith('/_next/static/')}
        for path in assets:
            content = request(base, path)
            if not content or content.lstrip().lower().startswith((b'<!doctype html', b'<html')):
                raise RuntimeError('Un fichier JavaScript/CSS de la nouvelle version ne se charge pas.')
    print('Contrôles fonctionnels OK : magasins, connexion, avis et moyennes dans la liste.', flush=True)


def preserve_runtime_files(project, stage):
    """Copy runtime assets/config locally; never print their contents."""
    old_runtime = project / '.next' / 'standalone'
    new_runtime = stage / '.next' / 'standalone'
    source_public = old_runtime / 'public'
    if not source_public.is_dir():
        source_public = project / 'public'
    target_public = new_runtime / 'public'
    if target_public.is_symlink():
        target_public.unlink()
    elif target_public.exists():
        shutil.rmtree(target_public)
    shutil.copytree(source_public, target_public, symlinks=True)
    for filename in ENV_FILES:
        source = old_runtime / filename
        if not source.is_file():
            source = project / filename
        if source.is_file():
            replace_entry(source, new_runtime / filename)
    # Keep previous hashed chunks for browsers that loaded the old page.
    old_static = project / '.next' / 'static'
    if old_static.is_dir():
        def keep_new(source, target):
            if not Path(target).exists():
                return shutil.copy2(source, target)
            return target
        shutil.copytree(old_static, stage / '.next' / 'static', dirs_exist_ok=True, copy_function=keep_new)
    target_static = new_runtime / '.next' / 'static'
    shutil.copytree(stage / '.next' / 'static', target_static, dirs_exist_ok=True)


def main():
    os.umask(0o077)
    if len(sys.argv) > 1 and sys.argv[1] == '--check':
        target = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else PROJECT
        manifest = json.loads((PACKAGE / 'manifest.json').read_text())
        verify_payload(PACKAGE, manifest)
        verify_base(target, manifest)
        print('Paquet vérifié et code compatible. Aucun changement effectué.')
        return
    if len(sys.argv) != 1:
        raise RuntimeError('Usage : python3 deploy.py [--check [chemin-du-projet]]')
    if os.getuid() == 0 or PROJECT.stat().st_uid != os.getuid():
        raise RuntimeError('Lancer ce script avec le compte franck, sans sudo devant python3.')
    lock = open(PROJECT.parent / '.branch-locator-deploy.lock', 'a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    manifest = json.loads((PACKAGE / 'manifest.json').read_text())
    verify_payload(PACKAGE, manifest)
    verify_base(PROJECT, manifest)
    if any(name.startswith('public/') for name in manifest):
        raise RuntimeError('Ce script est réservé à la mise à jour des avis sans changement des assets publics.')
    properties = unit_properties(SERVICE, ['ActiveState', 'MainPID', 'User', 'WorkingDirectory', 'ExecStart'])
    if properties.get('ActiveState') != 'active' or int(properties.get('MainPID', '0')) < 2:
        raise RuntimeError('Le service existant doit être actif avant cette mise à jour.')
    if properties.get('User') != 'franck' or properties.get('WorkingDirectory') != str(PROJECT):
        raise RuntimeError('Le service ne correspond pas à la configuration inspectée.')
    if str(PROJECT / '.next/standalone/server.js') not in properties.get('ExecStart', ''):
        raise RuntimeError('Commande de démarrage inattendue ; aucun changement effectué.')
    if shutil.disk_usage(PROJECT.parent).free < 3 * 1024 ** 3:
        raise RuntimeError('Au moins 3 Gio libres sont nécessaires pour préparer et conserver les deux versions.')
    if PROJECT.stat().st_dev != PROJECT.parent.stat().st_dev:
        raise RuntimeError('Le projet et le dossier de préparation doivent être sur le même système de fichiers.')
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    if int(memory['MemAvailable'].split()[0]) < 2 * 1024 ** 2:
        raise RuntimeError('Moins de 2 Gio de mémoire disponibles : différer la compilation sur le VPS.')
    # Read only the application bindings needed to build/test this application.
    # Values remain in process memory and are passed only to local child processes.
    process_environment = Path('/proc/' + properties['MainPID'] + '/environ').read_bytes()
    runtime = {}
    for entry in process_environment.split(b'\0'):
        if b'=' in entry:
            key, value = entry.split(b'=', 1)
            key = key.decode()
            if key in APP_KEYS or key.startswith('NEXT_PUBLIC_'):
                runtime[key] = value.decode()
    environment = os.environ.copy()
    for key in list(environment):
        if key in APP_KEYS or key.startswith('NEXT_PUBLIC_'):
            environment.pop(key)
    environment.update(runtime)
    environment['NODE_ENV'] = 'production'
    environment['NEXT_TELEMETRY_DISABLED'] = '1'
    environment['npm_config_cache'] = str(PROJECT.parent / '.cache' / 'branch-locator-npm')
    environment['NODE_OPTIONS'] = (environment.get('NODE_OPTIONS', '') + ' --max-old-space-size=1536').strip()
    # A working browser Maps key must remain available at build time.
    # Detect only its presence in the existing public bundles, never extract it.
    if any(re.search(rb'AIza[0-9A-Za-z_-]{35}', path.read_bytes())
           for path in (PROJECT / '.next' / 'static').rglob('*.js')):
        environment['BRANCH_DEPLOY_REQUIRE_MAPS'] = '1'
    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    work = PROJECT.parent / '.branch-locator-deployments' / timestamp
    stage = work / 'stage'
    work.mkdir(parents=True)
    print('Préparation isolée : ' + str(work), flush=True)
    print('Cible : ' + SERVICE + ' ; les autres services ne sont pas modifiés.', flush=True)
    checked(['sudo', '-v'])
    excluded = {'.git', '.next', 'node_modules', '.cache', 'playwright-report', 'test-results', 'coverage'}
    def ignore(_directory, names):
        return [name for name in names if name in excluded or name.startswith('.env') or name.endswith('.log')]
    shutil.copytree(PROJECT, stage, ignore=ignore, symlinks=True)
    for name in manifest:
        replace_entry(PACKAGE / 'source' / name, stage / name)
    for filename in ENV_FILES:
        source = PROJECT / '.next' / 'standalone' / filename
        if not source.is_file():
            source = PROJECT / filename
        if source.is_file():
            (stage / filename).symlink_to(source.resolve())
    # Install dev dependencies for the build as well as production dependencies.
    checked(['npm', 'ci', '--include=dev', '--no-audit', '--no-fund'], cwd=stage, env=environment)
    wrapper = [NODE, str(PACKAGE / 'run-with-env.cjs')]
    checked(wrapper + ['--validate'], cwd=stage, env=environment)
    print('Sauvegarde PostgreSQL via le service existant…', flush=True)
    before = unit_properties(BACKUP_SERVICE, ['ExecMainExitTimestampMonotonic'])
    checked(['sudo', 'systemctl', 'start', BACKUP_SERVICE])
    after = unit_properties(BACKUP_SERVICE, ['Result', 'ExecMainStatus', 'ExecMainExitTimestampMonotonic'])
    if after.get('Result') != 'success' or after.get('ExecMainStatus') != '0':
        raise RuntimeError('La sauvegarde PostgreSQL a échoué ; déploiement arrêté.')
    if int(after.get('ExecMainExitTimestampMonotonic', '0')) <= int(before.get('ExecMainExitTimestampMonotonic', '0')):
        raise RuntimeError('Aucune nouvelle sauvegarde terminée détectée ; déploiement arrêté.')
    print('Sauvegarde terminée avec succès.', flush=True)
    checked(wrapper + ['npx', '--no-install', 'prisma', 'generate'], cwd=stage, env=environment)
    checked(wrapper + ['npx', '--no-install', 'prisma', 'migrate', 'deploy'], cwd=stage, env=environment)
    checked(wrapper + ['npm', 'run', 'build'], cwd=stage, env=environment)
    preserve_runtime_files(PROJECT, stage)
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        candidate_port = listener.getsockname()[1]
    candidate_env = dict(environment, PORT=str(candidate_port), HOSTNAME='127.0.0.1')
    candidate_log = open(work / 'candidate.log', 'w')
    candidate = subprocess.Popen(wrapper + ['--serve', '.next/standalone/server.js'], cwd=stage,
                                 env=candidate_env, stdout=candidate_log, stderr=subprocess.STDOUT)
    try:
        candidate_url = 'http://127.0.0.1:' + str(candidate_port)
        wait_health(candidate_url, candidate)
        check_feature(candidate_url)
    finally:
        candidate.terminate()
        try:
            candidate.wait(timeout=10)
        except subprocess.TimeoutExpired:
            candidate.kill()
            candidate.wait()
        candidate_log.close()
    verify_base(PROJECT, manifest)
    switch = FileSwitch(PROJECT, stage, PACKAGE, manifest, work / 'rollback')
    port = int(runtime.get('PORT', '3000'))
    host = runtime.get('HOSTNAME', '127.0.0.1')
    host = {'0.0.0.0': '127.0.0.1', '::': '::1'}.get(host, host)
    if ':' in host:
        host = '[' + host + ']'
    live_url = 'http://' + host + ':' + str(port)
    stopped = False
    try:
        print('Bascule du service principal…', flush=True)
        stopped = True
        checked(['sudo', 'systemctl', 'stop', SERVICE])
        # Catch files uploaded/updated while the isolated build was running.
        preserve_runtime_files(PROJECT, stage)
        switch.promote()
        checked(['sudo', 'systemctl', 'start', SERVICE])
        wait_health(live_url)
        check_feature(live_url)
        wait_health(SITE)
        check_feature(SITE)
        if unit_properties(SERVICE, ['ActiveState']).get('ActiveState') != 'active':
            raise RuntimeError('Le service n’est pas actif après démarrage.')
    except BaseException:
        if stopped:
            print('Échec après bascule : restauration de la version précédente…', flush=True)
            checked(['sudo', 'systemctl', 'stop', SERVICE])
            switch.rollback()
            checked(['sudo', 'systemctl', 'start', SERVICE])
            wait_health(live_url)
            print('Version précédente redémarrée. La migration additive est conservée.', flush=True)
        raise
    (work / 'receipt.json').write_text(json.dumps({
        'status': 'deployed', 'service': SERVICE, 'site': SITE, 'timestamp': timestamp,
        'backup': str(work / 'rollback'), 'files': manifest,
    }, indent=2) + '\n')
    print('DEPLOIEMENT_REUSSI : ' + SITE, flush=True)
    print('Ancienne version conservée : ' + str(work / 'rollback'), flush=True)


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        # Never print process environments, dotenv contents, or credential URLs.
        print('DEPLOIEMENT_ARRETE : ' + str(error), file=sys.stderr)
        sys.exit(1)
