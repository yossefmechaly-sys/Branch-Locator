// Load the existing production dotenv files directly into child processes.
// Never serialize, print or export credential values to a deployment receipt.
const {loadEnvConfig} = require(require.resolve('@next/env', {paths: [process.cwd()]}));
loadEnvConfig(process.cwd(), false, {info() {}, error() {
  console.error('Impossible de charger les fichiers de configuration de production.');
  process.exit(1);
}});
if (process.argv[2] === '--validate') {
  const missing = ['DATABASE_URL', 'AUTH_SECRET', 'NEXT_PUBLIC_SITE_URL'].filter(key => !process.env[key]);
  if (process.env.BRANCH_DEPLOY_REQUIRE_MAPS === '1' && !process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY) {
    missing.push('NEXT_PUBLIC_GOOGLE_MAPS_API_KEY (carte existante)');
  }
  if (missing.length) {
    console.error('Configuration manquante : ' + missing.join(', '));
    process.exit(1);
  }
  const site = new URL(process.env.NEXT_PUBLIC_SITE_URL);
  if (site.origin !== 'https://branch-locator.tobedev.com') {
    console.error('NEXT_PUBLIC_SITE_URL ne correspond pas au site à déployer.');
    process.exit(1);
  }
  console.log('Configuration de production présente ; valeurs non affichées.');
} else if (process.argv[2] === '--serve') {
  require(require('node:path').resolve(process.argv[3]));
} else {
  const {spawnSync} = require('node:child_process');
  const [command, ...args] = process.argv.slice(2);
  const result = spawnSync(command, args, {stdio: 'inherit', env: process.env});
  if (result.error) console.error('Impossible de lancer la commande de préparation.');
  process.exit(result.status ?? 1);
}
