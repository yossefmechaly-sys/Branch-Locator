import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).with_name('deploy.py')
spec = importlib.util.spec_from_file_location('review_deploy', SCRIPT)
deploy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(deploy)


class DeploymentRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='deploy-recovery-', dir='/tmp')
        self.root = Path(self.tmp.name)
        self.live = self.root / 'live'
        self.stage = self.root / 'stage'
        self.package = self.root / 'package'
        self.manifest = {}
        for name, before, after in [('app/page.tsx', b'original page', b'updated page'),
                                    ('app/reviews/page.tsx', None, b'new reviews page')]:
            for path, value in [(self.live / name, before), (self.package / 'source' / name, after)]:
                if value is not None:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(value)
            self.manifest[name] = {
                'before_sha256': hashlib.sha256(before).hexdigest() if before else None,
                'after_sha256': hashlib.sha256(after).hexdigest(),
            }
        for base, content in [(self.live, 'old'), (self.stage, 'new')]:
            for folder in ['.next', 'node_modules']:
                path = base / folder / 'version'
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content)

    def tearDown(self):
        self.tmp.cleanup()

    def assert_restored(self):
        self.assertEqual((self.live / 'app/page.tsx').read_bytes(), b'original page')
        self.assertFalse((self.live / 'app/reviews/page.tsx').exists())
        for folder in ['.next', 'node_modules']:
            self.assertEqual((self.live / folder / 'version').read_text(), 'old')

    def test_switch_and_rollback_preserve_previous_code_and_both_artifacts(self):
        switch = deploy.FileSwitch(self.live, self.stage, self.package, self.manifest, self.root / 'backup')
        switch.promote()
        self.assertEqual((self.live / '.next/version').read_text(), 'new')
        self.assertEqual((self.live / 'app/reviews/page.tsx').read_bytes(), b'new reviews page')
        switch.rollback()
        self.assert_restored()

    def test_failure_midway_through_switch_can_restore_all_previous_artifacts(self):
        import shutil
        shutil.rmtree(self.stage / 'node_modules')
        switch = deploy.FileSwitch(self.live, self.stage, self.package, self.manifest, self.root / 'backup')
        with self.assertRaises(FileNotFoundError):
            switch.promote()
        switch.rollback()
        self.assert_restored()

    def test_modified_live_file_stops_compatibility_check(self):
        (self.live / 'app/page.tsx').write_text('unexpected server edit')
        with self.assertRaisesRegex(RuntimeError, 'différents'):
            deploy.verify_base(self.live, self.manifest)

    def test_altered_payload_is_rejected(self):
        (self.package / 'source/app/page.tsx').write_text('tampered payload')
        with self.assertRaisesRegex(RuntimeError, 'altéré'):
            deploy.verify_payload(self.package, self.manifest)

    def test_partial_application_is_rejected(self):
        (self.live / 'app/page.tsx').write_bytes(b'updated page')
        with self.assertRaisesRegex(RuntimeError, 'partielle'):
            deploy.verify_base(self.live, self.manifest)

    def test_runtime_photos_config_and_previous_static_chunks_are_preserved(self):
        old = self.live / '.next/standalone'
        new = self.stage / '.next/standalone'
        for path, content in [
            (old / 'public/uploads/photo.jpg', b'customer photo'),
            (old / '.env.production', b'TEST_ONLY=example'),
            (new / 'public/deleted-photo.jpg', b'stale candidate photo'),
            (self.live / '.next/static/old-chunk.js', b'old chunk'),
            (self.live / '.next/static/same-name.js', b'previous chunk'),
            (self.stage / '.next/static/same-name.js', b'new chunk'),
        ]:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        deploy.preserve_runtime_files(self.live, self.stage)
        self.assertEqual((new / 'public/uploads/photo.jpg').read_bytes(), b'customer photo')
        self.assertFalse((new / 'public/deleted-photo.jpg').exists())
        self.assertEqual((new / '.env.production').read_bytes(), b'TEST_ONLY=example')
        self.assertEqual((new / '.next/static/old-chunk.js').read_bytes(), b'old chunk')
        self.assertEqual((new / '.next/static/same-name.js').read_bytes(), b'new chunk')
        self.assertEqual((old / 'public/uploads/photo.jpg').read_bytes(), b'customer photo')

    def test_functional_check_verifies_frontend_assets_as_well_as_html(self):
        responses = {
            '/api/branches?locale=fr': b'{"branches":[{"slug":"ramot","reviewRating":{"total":0,"averageRating":null}}]}',
            '/he/branches': b'<a data-slot="branch-thumbnail" href="/he/branches/ramot#reviews">No reviews yet</a>',
            '/admin/login': b'<input type="password">',
            '/api/branches/ramot/reviews': b'{"reviews":[],"summary":{}}',
            '/fr/branches/ramot': b'Avis et satisfaction client<script src="/_next/static/new.js"></script>',
            '/_next/static/new.js': b'console.log("application");',
            '/_next/static/new.css': b'.locator-filter-menu{max-width:calc(100vw - 2rem)}',
        }
        for locale, title in deploy.HERO_TITLES.items():
            direction = 'rtl' if locale == 'he' else 'ltr'
            responses['/' + locale + '/branches'] = (
                '<html dir="' + direction + '"><div data-design="orange-locator">' + title +
                '</div><a data-slot="branch-thumbnail" href="/he/branches/ramot#reviews">Avis</a>' +
                '<link rel="stylesheet" href="/_next/static/new.css"><script src="/_next/static/new.js"></script></html>'
            ).encode()
            responses['/' + locale + '/branches/ramot?design=orange-branch-detail'] = (
                '<div data-design="orange-branch-detail">'
                '<h2 id="branch-gallery-heading">Photos</h2>'
                '<h2 id="branch-hours-heading">Hours</h2>'
                '<h2 id="branch-location-heading">Map</h2>'
                '<h2 id="branch-review-overview-heading">Ratings</h2>'
                '<section id="reviews">Reviews</section></div>'
                '<script src="/_next/static/new.js"></script>'
            ).encode()
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]) as request:
            deploy.check_feature('http://local')
            request.assert_any_call('http://local', '/_next/static/new.js')
        detail_path = '/es/branches/ramot?design=orange-branch-detail'
        new_detail = responses[detail_path]
        responses[detail_path] = b'<html>Old detail page</html>'
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]):
            with self.assertRaisesRegex(RuntimeError, 'pr.sentation des fiches manque : es'):
                deploy.check_feature('http://local')
        responses[detail_path] = new_detail
        missing_locale = responses['/ru/branches']
        responses['/ru/branches'] = b'<html>Old design</html>'
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]):
            with self.assertRaisesRegex(RuntimeError, 'traduction manque : ru'):
                deploy.check_feature('http://local')
        responses['/ru/branches'] = missing_locale
        responses['/_next/static/new.js'] = b'<!DOCTYPE html><html>Not found</html>' 
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]):
            with self.assertRaisesRegex(RuntimeError, 'JavaScript/CSS'):
                deploy.check_feature('http://local')


if __name__ == '__main__':
    unittest.main(verbosity=2)
