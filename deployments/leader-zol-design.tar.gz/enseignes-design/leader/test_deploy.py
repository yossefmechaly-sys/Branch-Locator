import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).with_name('deploy.py')
spec = importlib.util.spec_from_file_location('review_deploy', SCRIPT)
deploy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(deploy)


class DeploymentRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='deploy-recovery-', dir='/tmp')
        self.root = Path(self.tmp.name)
        self.live = self.root / 'live'
        self.stage = self.root / 'stage'
        self.package = self.root / 'package'
        self.manifest = {}
        for name, before, after in [('app/page.tsx', b'original page', b'updated page'),
                                    ('app/reviews/page.tsx', None, b'new reviews page')]:
            for path, value in [(self.live / name, before), (self.package / 'source' / name, after)]:
                if value is not None:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(value)
            self.manifest[name] = {
                'before_sha256': hashlib.sha256(before).hexdigest() if before else None,
                'after_sha256': hashlib.sha256(after).hexdigest(),
            }
        for base, content in [(self.live, 'old'), (self.stage, 'new')]:
            for folder in ['.next', 'node_modules']:
                path = base / folder / 'version'
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content)

    def tearDown(self):
        self.tmp.cleanup()

    def assert_restored(self):
        self.assertEqual((self.live / 'app/page.tsx').read_bytes(), b'original page')
        self.assertFalse((self.live / 'app/reviews/page.tsx').exists())
        for folder in ['.next', 'node_modules']:
            self.assertEqual((self.live / folder / 'version').read_text(), 'old')

    def test_switch_and_rollback_preserve_previous_code_and_both_artifacts(self):
        switch = deploy.FileSwitch(self.live, self.stage, self.package, self.manifest, self.root / 'backup')
        switch.promote()
        self.assertEqual((self.live / '.next/version').read_text(), 'new')
        self.assertEqual((self.live / 'app/reviews/page.tsx').read_bytes(), b'new reviews page')
        switch.rollback()
        self.assert_restored()

    def test_failure_midway_through_switch_can_restore_all_previous_artifacts(self):
        import shutil
        shutil.rmtree(self.stage / 'node_modules')
        switch = deploy.FileSwitch(self.live, self.stage, self.package, self.manifest, self.root / 'backup')
        with self.assertRaises(FileNotFoundError):
            switch.promote()
        switch.rollback()
        self.assert_restored()

    def test_modified_live_file_stops_compatibility_check(self):
        (self.live / 'app/page.tsx').write_text('unexpected server edit')
        with self.assertRaisesRegex(RuntimeError, 'différents'):
            deploy.verify_base(self.live, self.manifest)

    def test_altered_payload_is_rejected(self):
        (self.package / 'source/app/page.tsx').write_text('tampered payload')
        with self.assertRaisesRegex(RuntimeError, 'altéré'):
            deploy.verify_payload(self.package, self.manifest)

    def test_partial_application_is_rejected(self):
        (self.live / 'app/page.tsx').write_bytes(b'updated page')
        with self.assertRaisesRegex(RuntimeError, 'partielle'):
            deploy.verify_base(self.live, self.manifest)

    def test_runtime_photos_config_and_previous_static_chunks_are_preserved(self):
        old = self.live / '.next/standalone'
        new = self.stage / '.next/standalone'
        for path, content in [
            (old / 'public/uploads/photo.jpg', b'customer photo'),
            (old / '.env.production', b'TEST_ONLY=example'),
            (new / 'public/deleted-photo.jpg', b'stale candidate photo'),
            (self.live / '.next/static/old-chunk.js', b'old chunk'),
            (self.live / '.next/static/same-name.js', b'previous chunk'),
            (self.stage / '.next/static/same-name.js', b'new chunk'),
        ]:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        deploy.preserve_runtime_files(self.live, self.stage)
        self.assertEqual((new / 'public/uploads/photo.jpg').read_bytes(), b'customer photo')
        self.assertFalse((new / 'public/deleted-photo.jpg').exists())
        self.assertEqual((new / '.env.production').read_bytes(), b'TEST_ONLY=example')
        self.assertEqual((new / '.next/static/old-chunk.js').read_bytes(), b'old chunk')
        self.assertEqual((new / '.next/static/same-name.js').read_bytes(), b'new chunk')
        self.assertEqual((old / 'public/uploads/photo.jpg').read_bytes(), b'customer photo')

    def test_functional_check_verifies_frontend_assets_as_well_as_html(self):
        responses = {
            '/api/branches?locale=fr': b'{"branches":[{"slug":"ramot","reviewRating":{"total":0,"averageRating":null}}]}',
            '/admin/login': b'<input type="password">',
            '/api/branches/ramot/reviews': b'{"reviews":[],"summary":{}}',
            '/_next/static/new.js': b'console.log("application");',
            '/_next/static/new.css': (deploy.TARGET['primary_color'] + ' .map-branch-popup{}').encode(),
            deploy.TARGET['logo']: b'image bytes',
        }
        for locale, title in deploy.TARGET['hero_titles'].items():
            direction = 'rtl' if locale == 'he' else 'ltr'
            assets = '<link href="/_next/static/new.css"><script src="/_next/static/new.js"></script>'
            responses['/' + locale + '/branches'] = (
                '<html dir="' + direction + '"><h1>' + title + '</h1><div data-design="brand-locator">' +
                '<a data-slot="branch-thumbnail"><img src="' + deploy.TARGET['logo'] + '"></a></div>' + assets
            ).encode()
            schema = json.dumps({'@type': deploy.TARGET['store_type']})
            responses['/' + locale + '/branches/ramot?design=brand'] = (
                '<div data-design="brand-branch-detail">' +
                ''.join('<h2 id="' + marker + '">Section</h2>' for marker in [
                    'branch-gallery-heading','branch-hours-heading','branch-location-heading','branch-review-overview-heading']) +
                '<section id="reviews">Reviews</section></div>' + assets +
                '<script type="application/ld+json">' + schema + '</script>'
            ).encode()
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]) as request:
            deploy.check_feature('http://local')
            request.assert_any_call('http://local', '/_next/static/new.js')
        good_detail = responses['/he/branches/ramot?design=brand']
        responses['/he/branches/ramot?design=brand'] = good_detail.replace(deploy.TARGET['store_type'].encode(),b'WrongStoreType')
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]):
            with self.assertRaisesRegex(RuntimeError, 'cat.gorie de magasin'):
                deploy.check_feature('http://local')
        responses['/he/branches/ramot?design=brand'] = good_detail
        good_css = responses['/_next/static/new.css']
        responses['/_next/static/new.css'] = b'.map-branch-popup{color:black}'
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]):
            with self.assertRaisesRegex(RuntimeError, 'Palette'):
                deploy.check_feature('http://local')
        responses['/_next/static/new.css'] = good_css
        responses['/_next/static/new.js'] = b'<!DOCTYPE html><html>Not found</html>'
        with patch.object(deploy, 'request', side_effect=lambda base, path: responses[path]):
            with self.assertRaisesRegex(RuntimeError, 'JavaScript/CSS'):
                deploy.check_feature('http://local')


    def test_all_migrations_must_already_be_applied_for_a_design_update(self):
        stage = self.root / 'migration-source'
        for name in ('old_migration', '20261025000000_branch_reviews'):
            (stage / 'prisma/migrations' / name).mkdir(parents=True)
        database = {'migrations': [{'migration_name': name, 'finished': True, 'rolled_back': False} for name in ('old_migration','20261025000000_branch_reviews')]}
        deploy.check_migration_baseline(stage, database)
        with self.assertRaisesRegex(RuntimeError, 'historiques'):
            deploy.check_migration_baseline(stage, {'migrations': []})
        with self.assertRaisesRegex(RuntimeError, 'en échec'):
            deploy.check_migration_baseline(stage, {'migrations': [{'migration_name': 'old_migration', 'finished': False, 'rolled_back': False}]})

    def test_shared_database_stops_before_migration_or_switch(self):
        for name in ('branch-locator', 'leader-branch-locator', 'zol-uvegadol-branch-locator'):
            (self.root / name).mkdir()
        target = self.root / deploy.PROJECT_NAME
        with patch.object(deploy, 'PROJECT', target), patch.object(deploy, 'unit_properties', return_value={'MainPID': '0'}), patch.object(deploy.subprocess, 'check_output', return_value='{"identity":"same"}'):
            with self.assertRaisesRegex(RuntimeError, 'partagée'):
                deploy.check_database_isolation(self.root, self.root, ['node','helper'], {'identity': 'same'})

    def test_distinct_peer_databases_are_checked_separately(self):
        for name in ('branch-locator', 'leader-branch-locator', 'zol-uvegadol-branch-locator'):
            (self.root / name).mkdir()
        target = self.root / deploy.PROJECT_NAME
        with patch.object(deploy, 'PROJECT', target), patch.object(deploy, 'unit_properties', return_value={'MainPID': '0'}), patch.object(deploy.subprocess, 'check_output', side_effect=['{"identity":"main"}','{"identity":"zol"}']) as check:
            deploy.check_database_isolation(self.root, self.root, ['node','helper'], {'identity': 'leader'})
            self.assertEqual(check.call_count, 2)
            self.assertNotEqual(check.call_args_list[0].kwargs['cwd'], check.call_args_list[1].kwargs['cwd'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
